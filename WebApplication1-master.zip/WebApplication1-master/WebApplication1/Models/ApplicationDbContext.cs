using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext() : base("DefaultConnection")
        {
        }

        public DbSet<Appointment> Appointments { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<NewsletterSubscriber> NewsletterSubscribers { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>()
                .HasMany(u => u.Appointments)
                .WithRequired(a => a.User) 
                .HasForeignKey(a => a.PatientEmail);

            modelBuilder.Entity<User>()
                .HasIndex(u => u.Id) // Assuming 'Id' is  university ID field
                .IsUnique();
        }

        public System.Data.Entity.DbSet<WebApplication1.Models.Resetpss> Resetpsses { get; set; }
    }
}
