﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class NewsletterSubscriber
    {
        [Key]
        [EmailAddress]
        [Required]
        public string Email { get; set; }

        [Required]
        public bool IsSubscribed { get; set; }

        public string ConfirmationToken { get; set; }
    }

}
