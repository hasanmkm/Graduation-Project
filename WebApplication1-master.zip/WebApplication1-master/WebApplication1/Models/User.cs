﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class User
    {
        [Key]
        [Required]
        [Display(Name = "البريد الإلكتروني")]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 2)]
        [Display(Name = "الاسم الأول")]
        public string FirstName { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "الرقم الجامعي")]
        [Index(IsUnique = true)]
        public string Id { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 2)]
        [Display(Name = "اسم العائلة")]
        public string LastName { get; set; }

        [Phone]
        [Display(Name = "رقم الهاتف")]
        public string PhoneNumber { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? LastVisit { get; set; }

        public virtual ICollection<Appointment> Appointments { get; set; }
    }
}
