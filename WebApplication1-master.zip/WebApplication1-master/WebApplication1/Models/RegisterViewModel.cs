﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class CustomEmailAttribute : ValidationAttribute
    {
         public string AllowedDomain { get; }

        public CustomEmailAttribute(string allowedDomain)
        {
            AllowedDomain = allowedDomain;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                string email = value.ToString();
                if (email.EndsWith($"@{AllowedDomain}"))
                {
                    return ValidationResult.Success;
                }
                else
                {
                    return new ValidationResult($"يجب أن ينتهي الايميل ب '{AllowedDomain}'.");
                }
            }

            return ValidationResult.Success;
        }
    }

    public class RegisterViewModel
    {
        [Required]
        [Display(Name = "البريد الإلكتروني")]
        [EmailAddress(ErrorMessage = "يرجى إدخال بريد إلكتروني صالح.")]
        [CustomEmail("philadelphia.edu.jo", ErrorMessage = "يرجى إدخال البريد الالكتروني المنتهي ب 'philadelphia.edu.jo'!")]
        public string Email { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "يجب أن يكون الاسم الأول بين 2 و 50 حرفًا.")]
        [Display(Name = "الاسم الأول")]
        public string FirstName { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "يجب ألا يتجاوز الرقم الجامعي 50 حرفًا.")]
        [Display(Name = "الرقم الجامعي")]
        public string Id { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "يجب أن يكون اسم العائلة بين 2 و 50 حرفًا.")]
        [Display(Name = "اسم العائلة")]
        public string LastName { get; set; }

        [Phone(ErrorMessage = "يرجى إدخال رقم هاتف صالح.")]
        [Display(Name = "رقم الهاتف")]
        public string PhoneNumber { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "يجب أن تتكون كلمة المرور من 8 خانات على الأقل وأن تحتوي حرف كبير ورقم.", MinimumLength = 8)]
        [DataType(DataType.Password)]
        [RegularExpression("(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{8,}", ErrorMessage = "يجب أن تحتوي كلمة المرور على حرف كبير وحرف صغير ورقم.")]
        [Display(Name = "كلمة المرور")]
        public string Password { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "تأكيد كلمة المرور")]
        [Compare("Password", ErrorMessage = "كلمات المرور غير متطابقة.")]
        public string ConfirmPassword { get; set; }
    }
}
