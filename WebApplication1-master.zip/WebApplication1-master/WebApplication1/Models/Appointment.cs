using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class Appointment
    {
        public int Id { get; set; } 

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime Date { get; set; }

        [Required]
        public string Section { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime Time { get; set; }

        [MaxLength(500)] 
        public string Message { get; set; }

        [Required]
        [EmailAddress]
        public string PatientEmail { get; set; }

        [ForeignKey("PatientEmail")]
        public virtual User User { get; set; }

        public static implicit operator Appointment(List<Appointment> v)
        {
            throw new NotImplementedException();
        }
    }
}
