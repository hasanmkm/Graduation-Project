using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace WebApplication1.Models
{
    public class ReCaptchaService
    {
        private readonly HttpClient _httpClient;
        private const string GoogleRecaptchaVerificationUrl = "https://www.google.com/recaptcha/api/siteverify";
        private readonly string _secretKey;

        public ReCaptchaService(HttpClient httpClient, string secretKey)
        {
            _httpClient = httpClient;
            _secretKey = secretKey;
        }

        public async Task<bool> IsCaptchaValidAsync(string responseToken)
        {
            var response = await _httpClient.PostAsync(
                GoogleRecaptchaVerificationUrl,
                new FormUrlEncodedContent(new[]
                {
                new KeyValuePair<string, string>("secret", _secretKey),
                new KeyValuePair<string, string>("response", responseToken)
                }));

            if (response.IsSuccessStatusCode)
            {
                var jsonResult = await response.Content.ReadAsStringAsync();
                dynamic result = JsonConvert.DeserializeObject(jsonResult);
                return result.success;
            }
            return false;
        }
    }

}
