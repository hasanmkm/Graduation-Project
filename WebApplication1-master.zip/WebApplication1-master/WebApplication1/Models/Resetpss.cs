﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Resetpss
    {
        [Key]
        [Required(ErrorMessage = "الرجاء إدخال كلمة المرور الحالية")]
        [DataType(DataType.Password)]
        [Display(Name = "كلمة المرور الحالية")]
        public string OldPassword { get; set; }

        
        [StringLength(100, ErrorMessage = "يجب أن تتكون كلمة المرور من 8 خانات على الأقل وأن تحتوي حرف كبير ورقم.", MinimumLength = 8)]
        [DataType(DataType.Password)]
        [RegularExpression("(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{8,}", ErrorMessage = "يجب أن تحتوي كلمة المرور على حرف كبير وحرف صغير ورقم.")]
        [Display(Name = "كلمة المرور الجديدة")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "تأكيد كلمة المرور الجديدة")]
        [Compare("Password", ErrorMessage = "كلمات المرور غير متطابقة.")]
        public string ConfirmPassword { get; set; }

        public bool PasswordChangedSuccessfully { get; set; }
    }
}