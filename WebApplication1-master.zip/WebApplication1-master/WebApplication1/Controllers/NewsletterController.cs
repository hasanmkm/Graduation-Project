﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class NewsletterController : Controller
    {
        // Instantiate the context here
        private ApplicationDbContext _context = new ApplicationDbContext();

        // GET: NewsLetter
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Subscribe(string email)
        {
            // Validate email format
            if (string.IsNullOrEmpty(email) || !IsValidEmail(email))
            {
                TempData["ErrorMessage"] = "Please enter a valid email address.";
                return RedirectToAction("Index", "Home"); 
            }

            // Check if the email is already subscribed
            var existingSubscriber = _context.NewsletterSubscribers.FirstOrDefault(s => s.Email == email);

            if (existingSubscriber != null && existingSubscriber.IsSubscribed)
            {
                TempData["ErrorMessage"] = "This email is already subscribed to the newsletter.";
                return RedirectToAction("Index", "Home"); 
            }

            // If the subscriber exists but is not subscribed, update the subscription status
            if (existingSubscriber != null)
            {
                existingSubscriber.IsSubscribed = true;
                _context.SaveChanges();
            }
            else
            {
                // Add a new subscriber to the database
                var confirmationToken = Guid.NewGuid().ToString(); // Generate a confirmation token
                var newSubscriber = new NewsletterSubscriber
                {
                    Email = email,
                    IsSubscribed = true,
                    ConfirmationToken = confirmationToken,

                };

                _context.NewsletterSubscribers.Add(newSubscriber);
                _context.SaveChanges();

                // Send a confirmation email to the new subscriber
                SendConfirmationEmail(email, confirmationToken);
            }

            TempData["SuccessMessage"] = "Thank you for subscribing to the newsletter!";
            return RedirectToAction("Index", "Home"); 
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var mailAddress = new System.Net.Mail.MailAddress(email);
                return mailAddress.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private void SendConfirmationEmail(string email, string confirmationToken)
        {

            var smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential("EEE123@gmail.com", "your-email-password"),
                EnableSsl = true,
            };

            var confirmationLink = Url.Action("ConfirmSubscription", "Newsletter", new { email, token = confirmationToken }, Request.Url.Scheme);

            var message = new MailMessage
            {
                From = new MailAddress("EEE123@gmail.com", "Your Application Name"),
                Subject = "Newsletter Subscription Confirmation",
                Body = $"Thank you for subscribing to our newsletter! Click <a href=\"{confirmationLink}\">here</a> to confirm your subscription.",
                IsBodyHtml = true,
            };

            message.To.Add(email);

            smtpClient.Send(message);
        }

        public ActionResult ConfirmSubscription(string email, string token)
        {
            var subscriber = _context.NewsletterSubscribers.FirstOrDefault(s => s.Email == email && s.ConfirmationToken == token);

            if (subscriber != null)
            {


                _context.SaveChanges();
                TempData["SuccessMessage"] = "Subscription confirmed successfully!";
            }
            else
            {
                TempData["ErrorMessage"] = "Invalid confirmation link.";
            }

            return RedirectToAction("Index", "Home"); 
        }
    }
}
