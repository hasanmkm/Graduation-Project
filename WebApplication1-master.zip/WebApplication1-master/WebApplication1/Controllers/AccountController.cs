﻿using System;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using System.Web.Security;
using WebApplication1.Models;
using BCrypt.Net;
using Newtonsoft.Json;
using Recaptcha;
using System.Net.Http;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace WebApplication1.Controllers
{
    public class AccountController : Controller
    {
        private readonly ReCaptchaService _reCaptchaService;
        private ApplicationDbContext db = new ApplicationDbContext();

        public JsonResult CheckEmailDomain(string email)
        {
            string allowedDomain = "philadelphia.edu.jo";
            bool isValid = email.EndsWith($"@{allowedDomain}");

            return Json(new { isValid }, JsonRequestBehavior.AllowGet);
        }
        public AccountController()
        {
            var httpClient = new HttpClient();
            var secretKey = "6LfJzEspAAAAAMPrhqh-4_eGJF11pK5OyFPK9Ljv"; 
            _reCaptchaService = new ReCaptchaService(httpClient, secretKey);
        }
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Register(RegisterViewModel model)
        {
            string recaptchaResponse = Request.Form["g-recaptcha-response"];

            if (!await IsReCaptchaValid(recaptchaResponse))
            {
                ModelState.AddModelError(string.Empty, "الرجاء إكمال المتطلبات للتسجيل!");
                return View(model);
            }

            if (ModelState.IsValid)
            {
                var existingUserWithEmail = db.Users.FirstOrDefault(u => u.Email == model.Email);
                var existingUserWithId = db.Users.FirstOrDefault(u => u.Id == model.Id);

                if (existingUserWithEmail != null)
                {
                    ModelState.AddModelError("", "البريد الالكتروني مسجل مسبقاً!");
                    return View(model);
                }

                if (existingUserWithId != null)
                {
                    ModelState.AddModelError("Id", "الرقم الجامعي مسجل مسبقاَ");
                    return View(model);
                }

                var hashedPassword = BCrypt.Net.BCrypt.HashPassword(model.Password);

                var newUser = new User
                {
                    Email = model.Email,
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Id = model.Id,
                    PhoneNumber = model.PhoneNumber,
                    Password = hashedPassword
                };

                db.Users.Add(newUser);

                try
                {
                    db.SaveChanges();
                    return RedirectToAction("Login", "Account");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "حدث خطأ أثناء تسجيل الميتخدم! " + ex.Message);
                    return View(model);
                }
            }

            return View(model);
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                var user = db.Users.FirstOrDefault(u => u.Email == model.Email);

                if (user != null && BCrypt.Net.BCrypt.Verify(model.Password, user.Password))
                {
                    FormsAuthentication.SetAuthCookie(model.Email, false);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError("", "يوجد خطأ, الرجاء المحاولة مرة أخرى");
                }
            }

            return View(model);
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login", "Account");
        }

        private async Task<bool> IsReCaptchaValid(string recaptchaResponse)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var values = new Dictionary<string, string>
            {
                {"secret", "6LfJzEspAAAAAMPrhqh-4_eGJF11pK5OyFPK9Ljv"}, 
                {"response", recaptchaResponse},
                {"remoteip", Request.ServerVariables["REMOTE_ADDR"]}
            };

                    var content = new FormUrlEncodedContent(values);
                    var response = await client.PostAsync("https://www.google.com/recaptcha/api/siteverify", content);
                    var responseString = await response.Content.ReadAsStringAsync();
                    var captchaVerification = JsonConvert.DeserializeObject<ReCaptchaVerificationResponse>(responseString);

                    return captchaVerification.Success;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public class ReCaptchaVerificationResponse
        {
            [JsonProperty("success")]
            public bool Success { get; set; }

            [JsonProperty("challenge_ts")]
            public DateTime ChallengeTimestamp { get; set; }

            [JsonProperty("hostname")]
            public string Hostname { get; set; }

            [JsonProperty("error-codes")]
            public List<string> ErrorCodes { get; set; }
        }
    }
}
