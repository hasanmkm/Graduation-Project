﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Authorize]
    public class BookController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        public ActionResult Book()
        {
            ViewBag.IsSubmitted = TempData["IsSubmitted"] as bool? ?? false;
            return View();
        }

        [HttpPost]
        public ActionResult Book(string date, string time, string message, string Section)
        {
            if (message.Length > 200)
            {
                ModelState.AddModelError("message", "يجب أن يكون الملاحظات أقل من 200 حرف.");
                return View();
            }

            if (ModelState.IsValid)
            {
                var appointmentDate = DateTime.Parse(date);
                var appointmentTime = TimeSpan.Parse(time);

                if (!IsDateAvailable(appointmentDate, appointmentTime, Section))
                {
                    ModelState.AddModelError("", "الموعد غير متاح في هذا الوقت. يرجى اختيار وقت آخر.");
                    return View();
                }

                var currentUserEmail = User.Identity.Name;
                var currentUser = db.Users.FirstOrDefault(u => u.Email == currentUserEmail);


                if (currentUser == null)
                {
                    return RedirectToAction("Error", "Home"); 
                }

                var userAppointmentsOnDay = db.Appointments
            .Where(a => a.Date.Year == appointmentDate.Year &&
                        a.Date.Month == appointmentDate.Month &&
                        a.Date.Day == appointmentDate.Day &&
                        a.PatientEmail == currentUser.Email)
            .ToList();

                if (userAppointmentsOnDay.Count >= 3)
                {
                    ModelState.AddModelError("", "لا يمكنك حجز أكثر من ثلاثة مواعيد في يوم واحد.");
                    return View();
                }

                var combinedDateTime = new DateTime(appointmentDate.Year, appointmentDate.Month, appointmentDate.Day,
                                                     appointmentTime.Hours, appointmentTime.Minutes, appointmentTime.Seconds);

                var appointment = new Appointment
                {
                    Date = appointmentDate,
                    Time = combinedDateTime,
                    Message = message,
                    PatientEmail = currentUser.Email,
                    User = currentUser,
                    Section = Section
                };

                db.Appointments.Add(appointment);
                db.SaveChanges();

                TempData["IsSubmitted"] = true;
                return RedirectToAction("Book");
            }

            return View();
        }

        private bool IsDateAvailable(DateTime date, TimeSpan time, string Section)
        {
            var dayOfWeek = date.DayOfWeek;
            if (dayOfWeek != DayOfWeek.Monday && dayOfWeek != DayOfWeek.Tuesday && dayOfWeek != DayOfWeek.Wednesday && dayOfWeek != DayOfWeek.Saturday && dayOfWeek != DayOfWeek.Sunday)
            {
                return false;
            }

            // Fetch appointments for the given day and Section
            var appointmentsForTheDay = db.Appointments
                .Where(a => a.Date.Year == date.Year &&
                            a.Date.Month == date.Month &&
                            a.Date.Day == date.Day &&
                            a.Section == Section)
                .ToList();

            return !appointmentsForTheDay.Any(a => a.Time.TimeOfDay == time);
        }

        public JsonResult GetAvailableTimes(string date, string Section)
        {
            DateTime parsedDate;
            if (!DateTime.TryParse(date, out parsedDate))
            {
                return Json(new List<string>(), JsonRequestBehavior.AllowGet);
            }

            var dayOfWeek = parsedDate.DayOfWeek;
            if (dayOfWeek != DayOfWeek.Monday && dayOfWeek != DayOfWeek.Tuesday && dayOfWeek != DayOfWeek.Wednesday && dayOfWeek != DayOfWeek.Saturday && dayOfWeek != DayOfWeek.Sunday)
            {
                return Json(new List<string>(), JsonRequestBehavior.AllowGet);
            }

            var currentUserEmail = User.Identity.Name;

            var bookedTimeSpans = db.Appointments
                                    .Where(a => a.Date.Year == parsedDate.Year &&
                                                a.Date.Month == parsedDate.Month &&
                                                a.Date.Day == parsedDate.Day &&
                                                a.Section == Section) 
                                    .Select(a => a.Time)
                                    .ToList();

            var availableTimes = GenerateAvailableTimes()
                                    .Where(time => Convert.ToDateTime(date + " " + time) > DateTime.Now)
                                    .Except(bookedTimeSpans.Select(ts => ts.ToString(@"hh\:mm"))) // To Exclude already booked times
                                    .ToList();

            return Json(availableTimes, JsonRequestBehavior.AllowGet);
        }




        private IEnumerable<string> GenerateAvailableTimes()
        {


            var times = new List<string>();
            for (int hour = 8; hour <= 15.5; hour++) // Assuming appointments are from 8 AM to 3:45 PM
            {
                for (int minute = 0; minute < 60; minute += 15) // 15-minute intervals
                {
                    times.Add($"{hour:D2}:{minute:D2}");
                }
            }
            return times;
        }



    }
}




//var bookedTimes = bookedTimeSpans.Select(ts => ts.ToString(@"hh\:mm")).ToList();
//var availableTimes = GenerateAvailableTimes().Except(bookedTimes).ToList();
