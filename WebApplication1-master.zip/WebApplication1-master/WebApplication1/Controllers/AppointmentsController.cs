﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Authorize]
    public class AppointmentsController : Controller
    {
        private ApplicationDbContext Pdb = new ApplicationDbContext();

        public ActionResult Details()
        {
            var currentUserEmail = User.Identity.Name;
            var currentUser = Pdb.Users.FirstOrDefault(u => u.Email == currentUserEmail);

            if (currentUser == null)
            {
                return RedirectToAction("Error", "Home"); 
            }

 
            var appointments = Pdb.Appointments
                .Where(a => a.PatientEmail == currentUser.Email)
                .ToList();

            return View(appointments);
        }


        [HttpPost]
        public ActionResult DeleteAppointment(int id)
        {
            var appointmentToDelete = Pdb.Appointments.Find(id);

            if (appointmentToDelete != null)
            {
                Pdb.Appointments.Remove(appointmentToDelete);
                Pdb.SaveChanges();
            }

            return RedirectToAction("Details");
        }






        private ApplicationDbContext db = new ApplicationDbContext();

        public ActionResult EditAppointment(int id)
        {
            // Assume your logic to retrieve the appointment goes here
            var appointment = db.Appointments.Find(id);

            if (appointment == null)
            {
                return HttpNotFound();
            }

            // Set ViewBag.IsSubmitted to false initially
            ViewBag.IsSubmitted = false;

            return View(appointment);
        }

        [HttpPost]
        public ActionResult EditAppointment(int id, string date, string time, string message, string Section)
        {
            if (ModelState.IsValid)
            {
                var appointment = db.Appointments.Find(id);

                if (appointment == null)
                {
                    return HttpNotFound();
                }

                var appointmentDate = DateTime.Parse(date);
                var appointmentTime = TimeSpan.Parse(time);

                if (!IsDateAvailable(appointmentDate, appointmentTime, Section))
                {
                    ModelState.AddModelError("", "الموعد غير متاح في هذا الوقت. يرجى اختيار وقت آخر.");
                    ViewBag.IsSubmitted = false; // Set IsSubmitted to false if the ModelState is not valid
                    return View(appointment);
                }

                appointment.Date = appointmentDate;
                appointment.Time = new DateTime(appointmentDate.Year, appointmentDate.Month, appointmentDate.Day,
                    appointmentTime.Hours, appointmentTime.Minutes, appointmentTime.Seconds);
                appointment.Message = message;
                appointment.Section = Section;

                db.SaveChanges();

                ViewBag.IsSubmitted = true; // Set IsSubmitted to true after successfully saving changes
                return RedirectToAction("SuccessfullEdit", new { id = appointment.Id });
            }

            ViewBag.IsSubmitted = false; // Set IsSubmitted to false if ModelState is not valid
            return View();
        }


        private bool IsDateAvailable(DateTime date, TimeSpan time, string Section)
        {
            var dayOfWeek = date.DayOfWeek;
            if (dayOfWeek != DayOfWeek.Monday && dayOfWeek != DayOfWeek.Tuesday && dayOfWeek != DayOfWeek.Wednesday && dayOfWeek != DayOfWeek.Saturday && dayOfWeek != DayOfWeek.Sunday)
            {
                return false;
            }

            // Fetch appointments for the given day and Section
            var appointmentsForTheDay = db.Appointments
                .Where(a => a.Date.Year == date.Year &&
                            a.Date.Month == date.Month &&
                            a.Date.Day == date.Day &&
                            a.Section == Section)
                .ToList();

            return !appointmentsForTheDay.Any(a => a.Time.TimeOfDay == time);
        }

        public JsonResult GetAvailableTimes(string date, string Section)
        {
            DateTime parsedDate;
            if (!DateTime.TryParse(date, out parsedDate))
            {
                return Json(new List<string>(), JsonRequestBehavior.AllowGet);
            }

            var dayOfWeek = parsedDate.DayOfWeek;
            if (dayOfWeek != DayOfWeek.Monday && dayOfWeek != DayOfWeek.Tuesday && dayOfWeek != DayOfWeek.Wednesday && dayOfWeek != DayOfWeek.Saturday && dayOfWeek != DayOfWeek.Sunday)
            {
                return Json(new List<string>(), JsonRequestBehavior.AllowGet);
            }

            var currentUserEmail = User.Identity.Name;

            var bookedTimeSpans = db.Appointments
                                    .Where(a => a.Date.Year == parsedDate.Year &&
                                                a.Date.Month == parsedDate.Month &&
                                                a.Date.Day == parsedDate.Day &&
                                                a.Section == Section)
                                    .Select(a => a.Time)
                                    .ToList();

            var availableTimes = GenerateAvailableTimes()
                                    .Where(time => Convert.ToDateTime(date + " " + time) > DateTime.Now)
                                    .Except(bookedTimeSpans.Select(ts => ts.ToString(@"hh\:mm"))) // To Exclude already booked times
                                    .ToList();

            return Json(availableTimes, JsonRequestBehavior.AllowGet);
        }




        private IEnumerable<string> GenerateAvailableTimes()
        {


            var times = new List<string>();
            for (int hour = 8; hour <= 15.5; hour++) // Assuming appointments are from 8 AM to 3:45 PM
            {
                for (int minute = 0; minute < 60; minute += 15) // 15-minute intervals
                {
                    times.Add($"{hour:D2}:{minute:D2}");
                }
            }
            return times;
        }


        public ActionResult SuccessfullEdit()
        {
            return View();
        }


    }
}
