﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;


namespace WebApplication1.Controllers
{
    [Authorize]
    public class ProfileController : Controller
    {
        private ApplicationDbContext Pdb = new ApplicationDbContext();

        
        public new ActionResult Profile()
        {
            var currentUserEmail = User.Identity.Name;
            var currentUser = Pdb.Users.FirstOrDefault(u => u.Email == currentUserEmail);

            if (currentUser == null)
            {
                // Handle user not found...
                return RedirectToAction("Error", "Home"); 
            }

            var user1 = new User()
            {
                FirstName = currentUser.FirstName,
                LastName = currentUser.LastName,
                Email = currentUser.Email,
                Id = currentUser.Id,
                PhoneNumber = currentUser.PhoneNumber,
                Appointments= currentUser.Appointments,
            };


            return View(user1);
        }

        public ActionResult Resetpss(Resetpss model)
        {
            if (ModelState.IsValid)
            {
                var currentUserEmail = User.Identity.Name;
                var currentUser = Pdb.Users.FirstOrDefault(u => u.Email == currentUserEmail);

                if (currentUser == null)
                {
                    return RedirectToAction("Error", "Home");
                }

                try
                {
                    // Check if the old password is correct
                    if (BCrypt.Net.BCrypt.Verify(model.OldPassword, currentUser.Password))
                    {
                        // Check if the new password is different from the old password
                        if (!BCrypt.Net.BCrypt.Verify(model.Password, currentUser.Password))
                        {
                            // New password is different, update the password
                            currentUser.Password = BCrypt.Net.BCrypt.HashPassword(model.Password);

                            // Save changes to the database
                            Pdb.SaveChanges();

                            return RedirectToAction("successfullreset", "Profile");
                        }
                        else
                        {
                            // New password is the same as the old password
                            ModelState.AddModelError("", "كلمة المرور الجديدة لا يمكن ان تكون هي نفس كلمة المرور القديمة");
                            return View(model);
                        }
                    }
                    else
                    {
                        // Old password is incorrect
                        ModelState.AddModelError("", "كلمة المرور الحالية غير صحيحة");
                        return View(model);
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "An error occurred while changing password: " + ex.Message);
                    return View(model);
                }
            }

            return View(model);
        }

        public ActionResult successfullreset()
        {
            return View();
        }


    }
}