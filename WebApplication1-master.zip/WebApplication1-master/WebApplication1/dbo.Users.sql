﻿CREATE TABLE [dbo].[Users] (
    [Email]           NVARCHAR (128) NOT NULL,
    [FirstName]       NVARCHAR (50)  NOT NULL,
    [Id]              NVARCHAR (50)  NOT NULL,
    [LastName]        NVARCHAR (50)  NOT NULL,
    [PhoneNumber]     NVARCHAR (MAX) NULL,
    [Password]        NVARCHAR (100) NOT NULL,
    [ConfirmPassword] NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_dbo.Users] PRIMARY KEY CLUSTERED ([Id])
);

