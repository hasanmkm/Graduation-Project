﻿namespace WebApplication1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class YourMigrationName : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.NewsletterSubscribers",
                c => new
                    {
                        Email = c.String(nullable: false, maxLength: 128),
                        IsSubscribed = c.Boolean(nullable: false),
                        ConfirmationToken = c.String(),
                    })
                .PrimaryKey(t => t.Email);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.NewsletterSubscribers");
        }
    }
}
